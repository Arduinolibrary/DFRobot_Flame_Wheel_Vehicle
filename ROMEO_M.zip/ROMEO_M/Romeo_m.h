/*Romeo BLE mini���ļ�

  �汾��1.0

  board:Romeo BLE mini

  ��˾���ɶ���Ȥ�Ƽ����޹�˾

  ��վ��http://dfrobot.com.cn
*/

#ifndef Romeo_m_h
#define Romeo_m_h

#include <inttypes.h>
#define Forward 0
#define Reverse 1


class Romeo_mClass
{
  public:
    void Initialise();
	  void motorControl(int,int,int,int);
	  void motorControl_M1(int,int);
	  void motorStop_M1(int);
	  void motorStop_M2(int);
	  void motorControl_M2(int,int);
    void motorStop();
};

extern Romeo_mClass Romeo_m;

#endif